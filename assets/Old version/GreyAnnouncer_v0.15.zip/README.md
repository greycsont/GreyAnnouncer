### what does it do?
It will play a sound when you reach to a higher style rank!

You can add the sound by replace the .wav file in the **Audio** folder near the plugin.

And you can set the cooldown timer in the **config.ini**

### how to install it
1.install beplnex

2.get the directory to plugin folder in beplnex

3.drag everything in the .zip file to the folder ( highly recommanded to create a individual folder in plugin folder to put mod for easy management )

### how to add the rank sound
1.find the **audio** folder near the plugin

2.open the **audio** folder

3.add the sound you wanted to the rank sound file format only accept the .wav file

4.the rank sound file's name should rename to the specific format, include: D C B A S SS SSS U

similar to this:

D.wav

C.wav

B.wav

A.wav

S.wav

SS.wav

SSS.wav

U.wav

it is fine to not put all the rank sound in the folder, it will automatically skip the rank without the file

### how to customize the setting
currently there's only one settings to configure

1.open the **config.ini** near the mod

2.find what you want to edit

3.change it

### v0.1.5
fixed the bug that will crash the mod if without all the audio required

sorry for the 94 person who downloaded the mod.